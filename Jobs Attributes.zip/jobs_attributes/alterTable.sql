ALTER TABLE /*TABLE_PREFIX*/t_item_job_attr DROP i_salary_min ;
ALTER TABLE /*TABLE_PREFIX*/t_item_job_attr DROP i_salary_max ;
ALTER TABLE /*TABLE_PREFIX*/t_item_job_attr DROP i_salary_min_hour ;
ALTER TABLE /*TABLE_PREFIX*/t_item_job_attr DROP i_salary_max_hour ;
ALTER TABLE /*TABLE_PREFIX*/t_item_job_attr DROP e_salary_period ;