1. Upload theme (file: sofia.zip) via admin site or upload it into your webhost directly to themes folder
2. Download plugins on http://mb-themes.com/theme-plugins/sofia-plugins.zip
3. Upload & extract sofia-plugins.zip located into plugins folder: oc-content/plugins/
4. Install plugins via oc-admin
