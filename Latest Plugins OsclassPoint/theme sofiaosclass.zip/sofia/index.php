<?php
/*
  Theme Name: Osclass Sofia Premium Theme
  Theme URI: https://osclasspoint.com/osclass-themes/general/sofia-osclass-theme_i67
  Description: Osclass Sofia premium theme
  Version: 3.6.0
  Author: MB Themes
  Author URI: https://osclasspoint.com/
  Widgets: header,footer
  Theme update URI: sofia-theme-full-responsive
  Product Key: ynMUuxp3sXYa0tMj0dQn
*/
?>