<?php // REDIRECT USER TO REGISTER PAGE - AUTHENTIFICATION CENTRAL ?>
<?php header("Location:".osc_register_account_url()); ?>