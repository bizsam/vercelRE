<?php
/*
Theme Name: Osclass Patricia Premium Theme
Theme URI: https://osclasspoint.com/osclass-themes/general/patricia-osclass-theme_i65
Description: This is the Premium Osclass Patricia Theme, most powerful theme for osclass
Version: 1.7.2
Author: MB Themes
Author URI: https://osclasspoint.com
Widgets: header,footer
Theme update URI: patricia-osclass-premium-theme-full-responsive
Product Key: 8vXVx9jI59dxNSgj38xK
*/
?>