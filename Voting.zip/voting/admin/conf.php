<?php if (!defined('OC_ADMIN') || OC_ADMIN!==true) exit('Access is not allowed.');
  if( Params::getParam('plugin_action') == 'post' ) {

    /**
     * Save Item form
     */
    $type_vote    = Params::getParam('type_vote');
    $enable_item  = Params::getParam('enable_item');
    if($enable_item == 'on') {
      osc_set_preference('item_voting', '1', 'voting', 'BOOLEAN');
      if($type_vote == 'user') {
        osc_set_preference('open', '0', 'voting', 'BOOLEAN');
        osc_set_preference('user', '1', 'voting', 'BOOLEAN');
      } else if($type_vote == 'open') {
        osc_set_preference('open', '1', 'voting', 'BOOLEAN');
        osc_set_preference('user', '0', 'voting', 'BOOLEAN');
      }
    } else {
      osc_set_preference('item_voting', '0', 'voting', 'BOOLEAN');
    }

    /**
     * Save User form
     */
    $enable_user  = Params::getParam('enable_user');
    if($enable_user == 'on') {
      osc_set_preference('user_voting', '1', 'voting', 'BOOLEAN');
    } else {
      osc_set_preference('user_voting', '0', 'voting', 'BOOLEAN');
    }
    if(osc_version()<300) {
      echo '<div style="text-align:center; font-size:22px; background-color:#00bb00;"><p>' . __('Congratulations. The plugin is now configured', 'voting') . '.</p></div>' ;
      osc_reset_preferences();
    } else {
      ob_get_clean();
      osc_add_flash_ok_message(__('Congratulations. The plugin is now configured', 'voting'), 'admin');
      osc_admin_render_plugin(osc_plugin_folder(__FILE__) . 'conf.php');
    }
  }
?>

<div id="settings_form" style="padding-left: 15px; padding-right: 15px;">
  <div style="padding: 20px;">
    <div style="float: left; width: 100%;">
      <b style="font-size: 1.5em;"><?php _e('Items', 'voting');?></b>
      <form action="<?php echo osc_admin_base_url(true); ?>?page=plugins&action=renderplugin&file=<?php echo osc_plugin_folder(__FILE__).'conf.php'; ?>" method="POST">
        <input type="hidden" name="plugin_action" value="post" />
        <p><label><input type="checkbox" name="enable_item" <?php if(osc_get_preference('item_voting', 'voting')) echo 'checked="checked"';?>/> <?php _e('Enable for items', 'voting') ; ?></label></p>
        <div style="width: 100%;">
          <p>
            <input <?php if(!osc_get_preference('item_voting', 'voting')){ echo 'disabled=""'; }?> name="type_vote" value="open" id="open" type="radio" <?php if(osc_get_preference('open', 'voting')) echo 'checked="checked"'?>/>
            <label for="open" ><?php _e('Open voting', 'voting'); ?> (<?php _e('All can vote the items', 'voting'); ?>)</label>
          </p>
          <p>
            <input <?php if(!osc_get_preference('item_voting', 'voting')){ echo 'disabled=""'; }?>name="type_vote" value="user" id="user" type="radio" <?php if(osc_get_preference('user', 'voting')) echo 'checked="checked"'?>/>
            <label for="user"><?php _e('Users voting', 'voting'); ?> (<?php _e("Only registered users can vote", 'voting'); ?>)</label>
          </p>
        </div>
    </div>

    <div style="float: left; width: 100%;">
      <b style="font-size: 1.5em;"><?php _e('Users', 'voting');?></b>
        <p><label><input type="checkbox" name="enable_user" <?php if(osc_get_preference('user_voting', 'voting')) echo 'checked="checked"';?>/> <?php _e('Enable for users', 'voting') ; ?></label></p>
        <input class="btn btn-submit" type="submit" value="<?php _e('Save', 'voting'); ?>"/>
      </form>
    </div>
    <div style="clear:both;"></div>
  </div>
</div>
